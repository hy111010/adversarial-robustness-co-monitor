# High-cost experiments not performed in this revision

The following items were intentionally not run because the final revision was
restricted to existing logs, traces, checkpoints, and CSV files:

- ImageNet or another large-scale dataset.
- Architectures outside the current CIFAR/ResNet family.
- Large expansions of detector, intervention, or baseline seed counts.
- Retraining every FastAdv+ and GradAlign configuration or using new extensive
  hyperparameter searches.
- Full 10,000-image AutoAttack evaluation.
- Full-test PGD-50/multi-restart and AA-1k evaluation of the new no-replay
  checkpoint; the new experiment is used only for the matched five-seed
  intervention ablation.
- Threshold retuning intended to turn the ResNet-18 4/5 result into 5/5.
- New training under alternative warning horizons or CO definitions; these are
  evaluated offline on saved traces only.
- Systematic snapshot-copy latency, peak GPU memory, disk-storage policy, or
  large-model engineering benchmarks.

The existing completed 1,000-image AutoAttack-standard records are included as
explicitly labeled subset estimates because they correspond to the same four
checkpoints used in the strong-evaluation table. They do not replace the
unperformed full 10,000-image AutoAttack evaluation.
