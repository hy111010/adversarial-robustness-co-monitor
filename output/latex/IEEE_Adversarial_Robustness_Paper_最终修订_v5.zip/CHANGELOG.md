# Final revision changelog

## Immediate-action control and additional AA-1k

- Added a five-seed ``immediate switch without replay'' intervention using the
  frozen detector and training protocol. It starts PGD-2 on the next mini-batch
  and retains the already completed warning update.
- Compared no replay, epoch replay, and next-epoch switching on before-CO
  action, warning-to-start delay, clean accuracy, PGD-10 accuracy, and core
  runtime with 100,000-resample paired bootstrap intervals.
- The no-replay response acts before CO in 5/5 cases and reaches
  $83.06\pm0.65\%$ clean and $47.05\pm0.74\%$ PGD-10. Its PGD-10 difference
  from replay is $+0.22$ points with CI $[-0.22,+0.66]$.
- Reframed the causal claim: immediate action is timing-critical; rollback is
  neither required for 5/5 pre-collapse action nor supported as an endpoint
  accuracy improvement.
- Evaluated the existing seed-101 FastAdv+ and GradAlign checkpoints with the
  same fixed first-1,000-image AutoAttack-standard protocol. Results are
  42.40\% and 44.40\%, respectively.
- Split full-test PGD and AA-1k into separate tables so their evaluation-set
  sizes cannot be confused.

## Protocol and statistics

- Separated detector development, held-out detector evaluation, intervention
  ablation, non-event control, and baseline-comparison seed roles.
- Confirmed that the seven primary held-out detector events use seeds 101,
  202, 303, 404, 505, 606, and 707. Development seeds 17, 23, and 42 are not
  included in the 7/7 recall result.
- Reclassified the third planned CIFAR-100 collapse-prone trajectory as a
  non-event because it did not meet the registered CO definition. The
  CIFAR-100 denominator is now three non-event runs with one alarm episode.
- Preserved the frozen CIFAR-10 threshold, 60-update reporting horizon, and
  original CO event definition.

## New offline analyses

- Added threshold sensitivity for 0.10--0.24, including the exact frozen
  threshold 0.1663298875.
- Added warning-horizon sensitivity for 20, 40, 60, 80, and 100 updates.
- Added CO event-definition sensitivity using three reasonable alternatives.
- Added an objective signal-persistence audit for the two long-lead events.
- All sensitivity results were recomputed from saved traces without retraining.

## Method and claims

- Defined “attack-free monitor” as no auxiliary validation attack or extra
  model evaluation; FGSM adversarial examples remain part of base training.
- Added a local-linearity interpretation of gradient rotation and stated that
  cosine drop is an empirical proxy, not a necessary/sufficient condition or
  theoretical certificate.
- Reframed long warnings as safety triggers rather than calibrated
  time-to-collapse predictions.
- Restricted the ResNet-18 claim to unchanged-threshold architecture transfer
  and the CIFAR-100 claim to protocol transfer after dataset-specific
  calibration.
- Preserved the causal split: detector warning, PGD-2 recovery, and replay for
  timely action.

## Engineering and baselines

- Audited the replay snapshot: one in-memory model/optimizer/AMP-scaler copy
  plus Python, NumPy, PyTorch CPU/CUDA, and loader-generator RNG state.
- Clarified that reported core time excludes snapshot save/restore overhead.
- Documented FastAdv+ and GradAlign as controlled reimplementations and added
  their actual saved configuration parameters.
- Clarified that FastAdv+ online PGD probes add 3.14 minutes on average beyond
  its reported core time.
- Added representative checkpoint seeds and the fixed best-validation-PGD-10
  selection rule for the strong attack table.
- Restored the completed 1,000-image AutoAttack-standard results for the same
  four strong-evaluation checkpoints. The table and text explicitly distinguish
  these fixed-subset estimates from the full-test PGD results.

## Presentation

- Added an Appendix containing the three requested sensitivity tables and the
  long-lead audit.
- Added a dedicated limitations subsection.
- Retained the provided IEEE conference class and single-author formatting for
  Heng Zhang.
