# IEEE LaTeX paper project

Main file: `main.tex`

Compile with a standard LaTeX distribution:

```text
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

The current author block uses anonymous-review wording because no author name,
institution, or email was present in the provided materials. Replace the
`\author{...}` block in `main.tex` before a camera-ready submission.

Experimental scope:

- CIFAR-10 and PreActResNet-18
- five-seed collapse and intervention study
- held-out detector evaluation on seeds 101 and 202
- full-test Clean/FGSM/PGD evaluation
- official standard AutoAttack on a fixed 1,000-image test subset
